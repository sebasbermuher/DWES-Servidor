package org.iesalixar.servidor.dao;

import org.iesalixar.servidor.model.Oficinas;

public interface DAOOficinas {
	public Oficinas getOficinas(String city);
}
