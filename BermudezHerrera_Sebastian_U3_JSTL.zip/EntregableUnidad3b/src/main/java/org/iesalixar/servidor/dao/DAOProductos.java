package org.iesalixar.servidor.dao;

import java.util.List;

import org.iesalixar.servidor.model.Productos;

public interface DAOProductos {
	
	public List<Productos> getAllProducts();
//	public ArrayList<Productos> getProductSearch(String searchTerm);

}
