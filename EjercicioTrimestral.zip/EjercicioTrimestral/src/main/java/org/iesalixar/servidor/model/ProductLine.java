package org.iesalixar.servidor.model;

public class ProductLine {
	private String productLine;

	public ProductLine() {
		super();
	}

	public ProductLine(String productLine) {
		super();
		this.productLine = productLine;
	}

	public String getProductLine() {
		return productLine;
	}

	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

}
