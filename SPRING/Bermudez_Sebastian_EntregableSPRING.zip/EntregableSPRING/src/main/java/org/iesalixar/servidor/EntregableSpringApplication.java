package org.iesalixar.servidor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntregableSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntregableSpringApplication.class, args);
	}

}
