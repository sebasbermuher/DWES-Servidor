package org.iesalixar.servidor.dto;

import java.io.Serializable;

public class GradoDTO implements Serializable {
	private String nombre;

	public GradoDTO() {
		// TODO Auto-generated constructor stub
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
